-- AlterTable
ALTER TABLE "Subtask" ALTER COLUMN "description" DROP DEFAULT,
ALTER COLUMN "updatedAt" DROP DEFAULT;
