-- AlterTable
ALTER TABLE "KanbanColumn" ADD COLUMN     "color" TEXT NOT NULL DEFAULT '';
