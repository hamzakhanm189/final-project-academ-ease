import React from 'react';
import NextTopLoader from 'nextjs-toploader';

const TopLoader = () => {
  return <NextTopLoader color='#4776E6' showSpinner={false} />;
};

export default TopLoader;
