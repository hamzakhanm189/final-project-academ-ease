// PUBLIC ROUTES
export const PUBLIC_ROUTES = [
  '/',
  '/signup',
  '/signin',
  '/verify-email',
  '/forgot-password',
  '/reset-password',
  '/verify-reset-code',
];

export const MAX_TAGS_PER_TASK = 5;

export const PRIORITY_COLORS = {
  HIGHEST: 'bg-red-500/35',
  HIGH: 'bg-yellow-500/35',
  MEDIUM: 'bg-blue-500/35',
  LOW: 'bg-green-500/35',
  LOWEST: 'bg-gray-500/35',
};

export const CREDITS_ON_SUBTASKS_AI_SUGGESTION = 5;

export const CREDITS_ON_AI_NOTES = 3;

export const DAILY_CREDIT_LIMIT = 50;
