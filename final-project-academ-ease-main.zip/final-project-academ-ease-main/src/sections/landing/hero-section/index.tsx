import React from 'react';

type Props = {};

const HeroSection = (props: Props) => {
  return (
    <section className='px-4 py-8' id='hero'>
      HeroSection
    </section>
  );
};

export default HeroSection;
